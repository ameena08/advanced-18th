package com.UST.StudentServicesFeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentServicesFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
