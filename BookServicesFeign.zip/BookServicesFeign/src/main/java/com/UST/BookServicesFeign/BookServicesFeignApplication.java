package com.UST.BookServicesFeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookServicesFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookServicesFeignApplication.class, args);
	}

}
