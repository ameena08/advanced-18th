package com.UST.BookServicesFeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookServicesFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
